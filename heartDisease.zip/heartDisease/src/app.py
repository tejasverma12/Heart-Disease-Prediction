# import streamlit as st
# import pandas as pd
# import joblib

# # Load model
# model = joblib.load("../models/heart_model.pkl")

# # App configuration
# st.set_page_config(page_title="Heart Disease Predictor ❤️", layout="wide")

# # Custom CSS
# st.markdown("""
#     <style>
#     .main {
#         background-color: #f9f9f9;
#         padding: 2rem;
#     }
#     .stButton>button {
#         background-color: #ff4b4b;
#         color: white;
#         border-radius: 10px;
#         height: 3em;
#         width: 100%;
#         font-size: 16px;
#     }
#     .stButton>button:hover {
#         background-color: #ff6666;
#         color: white;
#     }
#     </style>
# """, unsafe_allow_html=True)

# # Title section
# st.title("❤️ Heart Disease Prediction App")
# st.markdown("### *Predict the risk of heart disease based on patient health data.*")

# # Layout: Split screen
# col1, col2 = st.columns(2)

# with col1:
#     st.subheader("🧍 Patient Details")
#     age = st.slider("Age", 18, 100, 50)
#     sex = st.selectbox("Sex", ["Male", "Female"])
#     cp = st.selectbox("Chest Pain Type (0–3)", [0, 1, 2, 3])
#     trestbps = st.number_input("Resting Blood Pressure (mm Hg)", 80, 200, 120)
#     chol = st.number_input("Cholesterol (mg/dl)", 100, 600, 200)
#     fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dl", [0, 1])
#     restecg = st.selectbox("Resting ECG Results", [0, 1])
    
# with col2:
#     st.subheader("💓 Medical Details")
#     thalach = st.number_input("Max Heart Rate Achieved", 60, 220, 150)
#     exang = st.selectbox("Exercise Induced Angina", [0, 1])
#     oldpeak = st.number_input("ST Depression (Oldpeak)", 0.0, 10.0, 1.0, step=0.1)
#     slope = st.selectbox("Slope of Peak Exercise ST Segment", [0, 1, 2])
#     ca = st.selectbox("Number of Major Vessels (0–3)", [0, 1, 2, 3])
#     thal = st.selectbox("Thalassemia (0–3)", [0, 1, 2, 3])

# # Convert sex to numeric
# sex = 1 if sex == "Male" else 0

# # Prepare input
# input_data = pd.DataFrame({
#     'age': [age], 'sex': [sex], 'cp': [cp],
#     'trestbps': [trestbps], 'chol': [chol],
#     'fbs': [fbs], 'restecg': [restecg],
#     'thalach': [thalach], 'exang': [exang],
#     'oldpeak': [oldpeak], 'slope': [slope],
#     'ca': [ca], 'thal': [thal]
# })

# # Display input summary
# st.markdown("### 📋 Input Summary")
# st.dataframe(input_data)

# # Prediction button
# if st.button("🔍 Predict Heart Disease Risk"):
#     prob = model.predict_proba(input_data)[0][1]
#     pred = model.predict(input_data)[0]

#     st.subheader("🔎 Prediction Result:")
#     if pred == 1:
#         st.error(f"⚠️ High Risk of Heart Disease — Probability: {prob*100:.2f}%")
#     else:
#         st.success(f"✅ Low Risk of Heart Disease — Probability: {prob*100:.2f}%")

#     st.progress(int(prob*100))



# New Code of this Page
import streamlit as st
import pandas as pd
import joblib

# Load your trained model
model = joblib.load("../models/heart_model.pkl")


# Page configuration
st.set_page_config(
    page_title="Heart Disease Predictor 💓",
    layout="wide",
    page_icon="💖"
)

# ====================== CUSTOM CSS ======================
st.markdown("""
<style>
/* Main Page */
.stApp {
    background: linear-gradient(135deg, #e3f2fd, #f9f9ff);
    font-family: "Segoe UI", sans-serif;
}

/* Title Styling */
h1 {
    text-align: center;
    font-weight: 700;
    color: #1565c0;
    text-shadow: 0px 0px 10px rgba(21,101,192,0.15);
    margin-bottom: 0;
}
h3 {
    text-align: center;
    color: #5a5a5a;
    font-weight: 400;
    margin-top: 0;
}

/* Card Containers */
.card {
    background-color: white;
    border-radius: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    padding: 25px;
    transition: transform 0.2s ease-in-out;
    border: 1px solid #e0e0e0;
}
.card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(21,101,192,0.2);
}

/* Input Labels */
label {
    color: #1565c0 !important;
    font-weight: 600 !important;
}

/* Buttons */
.stButton>button {
    background: linear-gradient(90deg, #2196f3, #42a5f5);
    color: white;
    border: none;
    border-radius: 12px;
    height: 50px;
    font-size: 17px;
    font-weight: bold;
    transition: 0.3s;
    width: 100%;
}
.stButton>button:hover {
    background: linear-gradient(90deg, #42a5f5, #64b5f6);
    transform: scale(1.02);
}

/* DataFrame */
[data-testid="stDataFrame"] {
    border-radius: 15px;
    box-shadow: 0px 0px 10px rgba(21,101,192,0.1);
}

/* Result Cards */
.result-card {
    background: linear-gradient(120deg, #bbdefb, #e3f2fd);
    border-radius: 20px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 6px 20px rgba(33,150,243,0.2);
    color: #0d47a1;
    font-size: 1.3rem;
    font-weight: bold;
    margin-top: 20px;
}
.result-card.success {
    background: linear-gradient(120deg, #c8e6c9, #e8f5e9);
    color: #1b5e20;
}
.result-card.danger {
    background: linear-gradient(120deg, #ffcdd2, #ffebee);
    color: #b71c1c;
}

/* Progress Bar */
[data-testid="stProgressBar"] > div > div > div > div {
    background-image: linear-gradient(to right, #2196f3, #64b5f6);
}
</style>
""", unsafe_allow_html=True)

# ====================== HEADER ======================
st.markdown("<h1>💓 Heart Disease Prediction Portal</h1>", unsafe_allow_html=True)
st.markdown("<h3>Assess heart disease risk using AI-based medical data analysis</h3>", unsafe_allow_html=True)
st.markdown("---")

# ====================== INPUT SECTIONS ======================
col1, col2 = st.columns(2)

with col1:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("🧍 Patient Information")
    age = st.slider("Age", 18, 100, 50)
    sex = st.selectbox("Sex", ["Male", "Female"])
    cp = st.selectbox("Chest Pain Type (0–3)", [0, 1, 2, 3])
    trestbps = st.number_input("Resting Blood Pressure (mm Hg)", 80, 200, 120)
    chol = st.number_input("Cholesterol (mg/dl)", 100, 600, 200)
    fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dl", [0, 1])
    restecg = st.selectbox("Resting ECG Results", [0, 1])
    st.markdown('</div>', unsafe_allow_html=True)

with col2:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("💊 Medical Details")
    thalach = st.number_input("Max Heart Rate Achieved", 60, 220, 150)
    exang = st.selectbox("Exercise Induced Angina", [0, 1])
    oldpeak = st.number_input("ST Depression (Oldpeak)", 0.0, 10.0, 1.0, step=0.1)
    slope = st.selectbox("Slope of Peak Exercise ST Segment", [0, 1, 2])
    ca = st.selectbox("Number of Major Vessels (0–3)", [0, 1, 2, 3])
    thal = st.selectbox("Thalassemia (0–3)", [0, 1, 2, 3])
    st.markdown('</div>', unsafe_allow_html=True)

# Convert sex
sex = 1 if sex == "Male" else 0

# Prepare input
input_data = pd.DataFrame({
    'age': [age], 'sex': [sex], 'cp': [cp],
    'trestbps': [trestbps], 'chol': [chol],
    'fbs': [fbs], 'restecg': [restecg],
    'thalach': [thalach], 'exang': [exang],
    'oldpeak': [oldpeak], 'slope': [slope],
    'ca': [ca], 'thal': [thal]
})

# ====================== INPUT SUMMARY ======================
st.markdown("### 🧾 Input Summary")
st.dataframe(input_data, use_container_width=True)

# ====================== PREDICTION ======================
if st.button("🔍 Predict Heart Disease Risk"):
    prob = model.predict_proba(input_data)[0][1]
    pred = model.predict(input_data)[0]

    if pred == 1:
        st.markdown(f"""
        <div class="result-card danger">
            ⚠️ High Risk of Heart Disease <br>
            Probability: {prob*100:.2f}%
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="result-card success">
            ✅ Low Risk of Heart Disease <br>
            Probability: {prob*100:.2f}%
        </div>
        """, unsafe_allow_html=True)

    st.progress(int(prob * 100))
